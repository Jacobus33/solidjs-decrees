import { Clock } from './clock';



function App() {
  return (
    <div>
      <div style="width: 600px; height: 600px; border: 1px solid red ">
        <Clock name="Solid" />
      </div>
    </div>
  )
}

export default App;
